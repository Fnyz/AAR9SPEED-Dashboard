
<?php

require_once "./Model/Prduct.php";
require_once "./Model/Ordr.php";

$prod = new Prduct();


$order = new Ordr();



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($_POST['action'] === 'insertOrder') {


        $order->Item_id = $_POST['code'];
        $order->Staff_id = $_POST['staff'];
        $order->quan = $_POST['quan'];
        $order->inserted();
    }


    if ($_POST['action'] === 'filter') {


        $prod->id = $_POST['catId'] ?? 'No record! found!';
        $res = $prod->filterItem();

        foreach ($res as $value) {
            extract($value);

            echo '<tr>';
            echo '<td>' . $ITEM_CODE . '</td>';
            echo '<td>' . $ITEM_NAME . '</td>';
            echo '<td>' . $ITEM_PRICE . '</td>';
            echo '<td>' . $ITEM_DESC . '</td>';
            echo '<td class="butt">
                                <form action="ProductView.php?action=view" method="post">
                                <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="getId("' . $ITEM_CODE . ' ")"><i class="fa-regular fa-pen-to-square"></i></a></i>
                                    <input type="hidden" value="' . $CATEGORY_ID . ' " name="id">
                                    <button type="submit" class="btn btn-success">DETAILS
                                    </button>
                                </form>
                   </td>';
            echo '</tr>';
        }
    }

    if ($_POST['action'] === 'delete') {


        $prod->id = $_POST['prodId'];
        $prod->deleteData();
    }

    if ($_POST['action'] === 'pass') {

        $order->id = $_POST['catId'];
        $pr =  $order->getProds();

        echo '  <option selected disabled="">Choose...</option>';

        foreach ($pr as $val) {
            extract($val);
            echo ' <option value="' . $ITEM_CODE . '">' . $ITEM_NAME . '</option>';
        }
    }


    if ($_POST['action'] === 'fillOut') {

        $order->id = $_POST['code'];
        $b = $order->placeProds();

        foreach ($b as $val) {
            extract($val);

            $div = '

                                       <div class="mb-3">
                                            ITEM CODE: 
                                            <input type="text" class="form-control" placeholder="Product Code" value="' . $ITEM_CODE . '" id="Code" required disabled>
                                        </div>
                                        <div class="mb-3">
                                            PRODUCT NAME:
                                            <input type="text" class="form-control" placeholder="Product Name" value="' . $ITEM_NAME . '" id="Product" required disabled>
                                        </div>
                                        <div class="mb-3">
                                             PRICE:
                                            <input type="number" class="form-control" placeholder="Price" value="' . $ITEM_PRICE . '" id="Price" required disabled>
                                        </div>
                                        <div class="mb-3">
                                             QUANTITY:
                                            <input type="number" class="form-control" placeholder="Quantity" value="' . $total_quan . '" id="Quantity" required disabled>
                                        </div>
                                       

';

            echo $div;
            break;
        }
    }





    if ($_POST['action'] === 'updating') {

        $prod->id = $_POST['id'];
        $prod->prod = $_POST['Pname'];
        $prod->price = $_POST['price'];
        $prod->desc = $_POST['desc'];
        $prod->quantity = $_POST['quantity'];
        $prod->UpdateMe();
    }


    if ($_POST['action'] === 'getSingleProd') {


        $prod->id = $_POST['ProdId'];
        $val = $prod->getSingle();

        extract($val);

        $div = '

        <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">UPDATE CUSTOMER</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                         PRODUCT NAME: 
                        <input type="text" class="form-control" placeholder="Name" value="' . $ITEM_CODE . '" disabled>
                    </div>
                    <div class="mb-3">
                         PRODUCT NAME: 
                        <input type="text" class="form-control" placeholder="Name" value="' . $ITEM_NAME . '" id="prodName">
                    </div>
                    <div class="mb-3">
                        PRODUCT_PRICE
                        <input type="number" class="form-control" placeholder="Lastname" value="' . $ITEM_PRICE . '" id="prodPrice">
                    </div>
                    <div class="mb-3">
                        PRODUCT_DESC
                        <input type="text" class="form-control" placeholder="Phone number" value="' . $ITEM_DESC . '" id="prodDesc">
                    </div>
                    <div class="mb-3">
                        PRODUCT_QUANTITY
                        <input type="email" class="form-control" placeholder="Email" value="' . $TOTAL_COUNT . '" id="prodQuan">
                    </div>
                    <div class="mb-3">
                        PRODUCT_QUANTITY
                        <input type="email" class="form-control" placeholder="Email" value="' . $ITEM_CREATED_AT . '" disabled>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="updateME(' . $ITEM_ID . ')">Save changes</button>
                </div>
        

        ';

        echo $div;
    }
}








?>