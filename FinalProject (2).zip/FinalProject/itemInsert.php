<?php


require_once "./Model/Prduct.php";
$prod = new Prduct();


if ($_GET['action'] === "insert") {

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {


        if (isset($_POST['save'])) {



            $catId = $_POST['category'];
            $suppId = $_POST['supplier'];
            $prod->prod = $_POST['Product'];
            $prod->desc = $_POST['Descrip'];
            $prod->price = $_POST['Price'];
            $prod->quantity = $_POST['Quantity'];
            $prod->code = $_POST['Code'];
            $prod->category = $catId;
            $prod->supplier = $suppId;

            if ($prod->insertItem()) {
                header("Location: Product.php");
            };
        }
    }
}
