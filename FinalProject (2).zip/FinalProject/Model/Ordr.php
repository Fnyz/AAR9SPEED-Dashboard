



<?php
include_once "config/Database/Database.php";

class Ordr extends Database
{

    public $Item_id;
    public $Staff_id;
    public $quan;
    public $id;
    public $table = "staff";
    public $purchase = 'purchase_order';
    public $stats = 'Active';


    public function inserted()
    {


        $sql = "INSERT INTO " . $this->purchase . " (ITEM_ID, STAFF_ID, PORD_QUANTITY, PORD_STATUS, PORD_DATE, PORD_CREATED_AT, PORD_UPDATED_AT)
        VALUES (:ITEM_ID, :STAFF_ID, :PORD_QUANTITY, :PORD_STATUS, now(), now(), now())";
        $stmt = $this->getConnect()->prepare($sql);

        $stmt->bindParam(":ITEM_ID", $this->Item_id);
        $stmt->bindParam(":STAFF_ID", $this->Staff_id);
        $stmt->bindParam(":PORD_QUANTITY", $this->quan);
        $stmt->bindParam(":PORD_STATUS", $this->stats);

        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s \n", $stmt->error);
        return false;
    }

    public function showCustomer()
    {
        $sql = "SELECT * FROM " . $this->table . "";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function deleteData()
    {
        $sql = "DELETE FROM " . $this->table . " WHERE CUS_ID = :CUS_ID";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":CUS_ID", $this->id);
        if ($stmt->execute()) {
            return true;
        }
        printf("Error: %s \n", $stmt->error);
        return false;
    }

    public function getSingle()
    {
        $sql = "SELECT * FROM " . $this->table . " WHERE CUS_ID = :CUS_ID";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":CUS_ID", $this->id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getStaff()
    {
        $sql = "SELECT * FROM " . $this->table . "";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getCategory()
    {
        $sql = "SELECT * FROM category";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getProds()
    {
        $sql = "SELECT *,sum(ITEM_QUANTITY) as total_quan from item where CATEGORY_ID = :CATEGORY_ID GROUP BY ITEM_CODE;";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":CATEGORY_ID", $this->id);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function placeProds()
    {
        $sql = "SELECT *,sum(ITEM_QUANTITY) as total_quan from item where ITEM_CODE = :ITEM_CODE";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":ITEM_CODE", $this->id);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
}




?>

