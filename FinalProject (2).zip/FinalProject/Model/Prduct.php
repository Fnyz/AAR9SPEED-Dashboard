

<?php
include_once "config/Database/Database.php";

class Prduct extends Database
{

    public $prod;
    public $price;
    public $desc;
    public $quantity;
    public $supplier;
    public $category;
    public $table = "item";
    public $id;
    public $code;



    public function insertItem()
    {


        $sql = "INSERT INTO " . $this->table . " (ITEM_NAME, ITEM_DESC, ITEM_PRICE, ITEM_QUANTITY, CATEGORY_ID, SUPPLIER_ID, ITEM_CREATED_AT, ITEM_UPDATED_AT, ITEM_CODE)
        VALUES (:ITEM_NAME, :ITEM_DESC, :ITEM_PRICE, :ITEM_QUANTITY, :CATEGORY_ID , :SUPPLIER_ID , now(), now(), :ITEM_CODE)";
        $stmt = $this->getConnect()->prepare($sql);



        $stmt->bindParam(":ITEM_NAME", $this->prod);
        $stmt->bindParam(":ITEM_DESC", $this->desc);
        $stmt->bindParam(":ITEM_PRICE", $this->price);
        $stmt->bindParam(":ITEM_QUANTITY", $this->quantity);
        $stmt->bindParam(":CATEGORY_ID", $this->category);
        $stmt->bindParam(":SUPPLIER_ID", $this->supplier);
        $stmt->bindParam(":ITEM_CODE", $this->code);


        if ($stmt->execute()) {

            return true;
        }

        printf("Error: %s \n", $stmt->error);
        return false;
    }

    public function showProduct()
    {
        $sql = "SELECT * FROM " . $this->table . " t GROUP BY ITEM_NAME";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }


    public function filterItem()
    {
        $sql = "Select * from " . $this->table . " t inner join category c on 
        t.CATEGORY_ID = c.CATEGORY_ID WHERE t.CATEGORY_ID = {$this->id} GROUP BY ITEM_NAME";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }



    public function getSupplier()
    {
        $sql = "SELECT * FROM supplier";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function getCategory()
    {
        $sql = "SELECT * FROM category";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }

    public function deleteData()
    {
        $sql = "DELETE FROM " . $this->table . " WHERE ITEM_ID = :ITEM_ID";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":ITEM_ID", $this->id);
        if ($stmt->execute()) {
            return true;
        }
        printf("Error: %s \n", $stmt->error);
        return false;
    }


    public function getSingle()
    {
        $sql = "SELECT *,SUM(ITEM_QUANTITY) as TOTAL_COUNT FROM " . $this->table . " WHERE ITEM_CODE = :ITEM_CODE";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->bindParam(":ITEM_CODE", $this->id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result;
    }

    public function UpdateMe()
    {
        $sql = "UPDATE " . $this->table . " SET ITEM_NAME = :ITEM_NAME, ITEM_PRICE = :ITEM_PRICE, ITEM_DESC = :ITEM_DESC, ITEM_QUANTITY = :ITEM_QUANTITY, ITEM_UPDATED_AT = now() WHERE ITEM_ID= :ITEM_ID ";
        $stmt = $this->getConnect()->prepare($sql);


        $stmt->bindParam(":ITEM_ID", $this->id);
        $stmt->bindParam(":ITEM_NAME", $this->prod);
        $stmt->bindParam(":ITEM_PRICE", $this->price);
        $stmt->bindParam(":ITEM_DESC", $this->desc);
        $stmt->bindParam(":ITEM_QUANTITY", $this->quantity);


        if ($stmt->execute()) {
            return true;
        }

        printf("Error: %s \n", $stmt->error);
        return false;
    }
    public function showDetails()
    {
        $sql = "SELECT * FROM " . $this->table . " inner join category ON item.CATEGORY_ID = category.CATEGORY_ID join supplier on item.SUPPLIER_ID = supplier.SUPPLIER_ID WHERE category.CATEGORY_ID = {$this->id}";
        $stmt = $this->getConnect()->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
}








?>

