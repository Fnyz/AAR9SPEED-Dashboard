

<?php

include_once "./Model/sqlnotification.php";

$notify = new sqlnotification();


if (isset($_POST['view'])) {

    $depleted = '';
    if (count($notify->showdepleted()) > 0) {
        $r = $notify->showdepleted();


        foreach ($r as $val) {
            extract($val);

            $depleted .= '
            <li>
            <a class="dropdown-item" href="Product.php">
<strong class="text text-primary">' . $ITEM_NAME . '</strong> <em> is <small class="text text-success">depleted </small> product.</a>
            </li></em> 
            ';
        }
    }

    $pending = '';
    if (count($notify->showdepleted()) > 0) {
        $s = $notify->showPending();


        foreach ($s as $val) {
            extract($val);

            $pending .= '
            <li>
            <a class="dropdown-item" href="pendingProduct.php"><strong class="text text-success">' . $ITEM_NAME . '</strong><em> is a <small class="text text-danger"> pending </small> product. </a>
            </li></em> 
            ';
        }
    }


    $count = $notify->count();

    $data = array(
        'depleted' => $depleted,
        'pending' => $pending,
        'unseen' => $count
    );
    echo json_encode($data);
}

?>

