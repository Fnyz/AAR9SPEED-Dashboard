<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/log.css">
    <?php
    require_once "../FinalProject/styles/stylish.php";
    ?>
    <title>LoginPage</title>

</head>

<body>
    <form action="">
        <div>
            <img src="img/logo.png" alt="" srcset="">
            <div class="input-group mb-3 mother">
                <span class="input-group-text" id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                <input type="text" class="form-control" placeholder="Username" name="username">
            </div>
            <div class="input-group mb-3 ">
                <span class="input-group-text" id="basic-addon1"><i class="fa-solid fa-key"></i></span>
                <input type="password" class="form-control" placeholder="Password" name="pass">
            </div>
            <button type="submit" class="btn btn-danger">Login</button>
            <a href="Dashboard.php" class=" text text-primary">Forget Password?</a>
        </div>
    </form>




</body>

</html>