 <div class="load">

     <img src="./img/logo.png" alt="">
     <div class="loader">
         <span></span>
         <span></span>
         <span></span>
     </div>

 </div>