<?php
require_once "./Model/Cstomer.php";

$cust = new Cstomer();
$profile = $cust->showCustomer();

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="styles/Cust.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/select/1.5.0/css/select.bootstrap5.min.css">

    <?php
    require_once "../FinalProject/styles/stylish.php";
    ?>
</head>

<body>




    <div class="ham"> <button class="btn " type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling"><i class="fa-solid fa-bars text-black"></i></button></div>
    <div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
        <div class="offcanvas-header sides">
            <img src="img/logo.png" class="offcanvas-title" id="offcanvasScrollingLabel" width="300px"></img>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body sides">
            <div class="card sides" style="width: 18rem;">
                <div class="rnd">
                    <i class="fa-solid fa-user"></i>
                </div>
                <div class="card-body ">
                    <h5 class="card-title">
                        <i class="fa-solid fa-pen"></i>
                        Dadi BUSICS
                    </h5>
                    <div class="btns">
                        <a href="" data-bs-toggle="modal" data-bs-target="#UpdateAdmin" class="btn btn-success">UPDATE</a>
                        <a href="#" class="btn btn-danger">LOG-OUT</a>
                    </div>
                </div>
            </div>

            <div class="list-group ">
                <a href="Dashboard.php" class="list-group-item list-group-item-action sides " aria-current="true">
                    <i class="fa-sharp fa-solid fa-house-user"></i>HOME</a></li>
                </a>
                <a href="Customer.php" class="list-group-item list-group-item-action active"><i class="fa-sharp fa-solid fa-users"></i>CUSTOMER</a></li></a>
                <a href="Staff.php" class="list-group-item list-group-item-action sides"><i class="fa-solid fa-user-plus"></i>STAFF</a></li></a>
                <a href="Product.php" class="list-group-item list-group-item-action sides"><i class="fa-sharp fa-solid fa-cart-shopping"></i>PRODUCT</a>
                <a href="Invoice.php" class="list-group-item list-group-item-action sides"><i class="fa-solid fa-receipt"></i> INVOICE</a>
                <a href="Supplier.php" class="list-group-item list-group-item-action sides"><i class="fa-sharp fa-solid fa-user"></i>SUPPLIER</a>
                <a href="Order.php" class="list-group-item list-group-item-action sides"><i class="fa-solid fa-bag-shopping"></i>PURCHASE ORDER</a>

            </div>

        </div>
    </div>
    <div class="red">

        <section class="con">
            <h2>CUSTOMER</h2>
            <div>

                <table id="example" class="table table-striped" style="width:100%">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>LastName</th>
                            <th>Address</th>
                            <th> Email</th>
                            <th>PhoneNumber</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($profile as $value) : extract($value) ?>
                            <tr>

                                <td><?php echo $CUS_ID ?></td>
                                <td><?php echo $CUS_FNAME ?></td>
                                <td><?php echo $CUS_LNAME ?></td>
                                <td><?php echo $CUS_ADDRESS ?></td>
                                <td><?php echo $CUS_EMAIL ?></td>
                                <td><?php echo $CUS_PHONENUM ?></td>
                                <td class="butt">
                                    <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="getId(<?php echo $CUS_ID ?>)"><i class="fa-regular fa-pen-to-square"></i></a></i>

                                    <a href="" data-bs-toggle="modal" data-bs-target="#View">
                                        <i class="fa-sharp fa-solid fa-eye-slash" onclick="viewSingle(<?php echo $CUS_ID ?>)"></i>
                                    </a>

                                    <a href=""><i class="fa-solid fa-trash" onclick="deleteOne(<?php echo $CUS_ID ?>)"></i></a>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="sideBtn">

                    <!-- Button trigger modal -->

                    <div id="addBtn">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            <i class="fa-solid fa-plus"></i>ADD CUSTOMER
                        </button>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="staticBackdropLabel">ADD CUSTOMER</h1>

                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>


                                <div class="modal-body">
                                    <div class="mb-3">

                                        <input type="text" class="form-control" placeholder="Name" id="Fname" name="name">
                                    </div>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="Lastname" id="Lname" name="lastname">
                                    </div>
                                    <div class="mb-3">
                                        <input type="number" class="form-control" placeholder="Phone number" id="Pnum" name="phone">
                                    </div>
                                    <div class="mb-3">
                                        <input type="email" class="form-control" placeholder="Email" id="email" name="email">
                                    </div>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="Address" id="address" name="address">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary save" onclick="saveBtn()">Save</button>
                                </div>


                            </div>
                        </div>
                    </div>


                </div>
        </section>



    </div>




    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" id="ViewUpdate">


            </div>
        </div>
    </div>





    <!-- View -->
    <div class="modal fade" id="View" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">INFORMATION</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="expand">
                        <div class="card-body" id="ViewPage">

                        </div>

                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <?php require_once "./styles/updateAccount.php" ?>
    <?php require_once "scripts/jquaryScript.php" ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.5.0/js/dataTables.select.min.js"></script>


    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                select: true
            });
        });

        function saveBtn() {

            var $name = $('#Fname').val();
            var $last = $('#Lname').val();
            var $phone = $('#Pnum').val();
            var $email = $('#email').val();
            var $add = $('#address').val();


            $.post('operation.php', {
                name: $name,
                lastname: $last,
                address: $add,
                email: $email,
                phone: $phone,
                action: 'insert'
            }, function(data, status) {

                location.reload();
                $('#Fname').val("");
                $('#Lname').val("");
                $('#Pnum').val("");
                $('#email').val("");
                $('#address').val("");

            })

        }


        function deleteOne(id) {

            $.post('operation.php', {

                Cus_id: id,
                action: 'delete'
            }, function(data, status) {

                location.reload();
                console.log(status);
            })
        }

        function getId(id) {


            var thing = $('#ViewUpdate');

            $.get('operation.php', {

                Cus_id: id,
                action: 'getSingle'
            }, function(data, status) {

                thing.html(data);
            })
        }



        function viewSingle(id) {


            var thing = $('#ViewPage');

            $.get('operation.php', {

                id: id,
                action: 'viewSingle'
            }, function(data, status) {

                thing.html(data);
            })
        }

        function updateME(id) {

            var $name = $('#fname').val();
            var $last = $('#lname').val();
            var $add = $('#add').val();
            var $email = $('#emls').val();
            var $phone = $('#nums').val();




            $.post('operation.php', {
                id: id,
                name: $name,
                lastname: $last,
                address: $add,
                email: $email,
                phone: $phone,
                action: 'updating'
            }, function(data, status) {

                location.reload();

            })
        }
    </script>




</body>

</html>